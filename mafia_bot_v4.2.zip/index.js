
const fs = require("fs");
const path = require("path");
const { Client, GatewayIntentBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const sqlite3 = require("sqlite3").verbose();
const cfg = require("./config.json");
const prefix = cfg.prefix || ".";
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });

function isOwner(id){ return cfg.owners.includes(id); }

// points DB
const db = new sqlite3.Database("./points.db");
db.run("CREATE TABLE IF NOT EXISTS points (id TEXT PRIMARY KEY, score INTEGER DEFAULT 0)");

function addPoints(id, amount){
  db.run("INSERT INTO points(id,score) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET score=score+?", [id, amount, amount]);
}
function setPoints(id, amount){
  db.run("INSERT INTO points(id,score) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET score=?", [id, amount, amount]);
}
function getPoints(id, cb){
  db.get("SELECT score FROM points WHERE id=?", [id], (err,row)=>cb(row?row.score:0));
}

client.on("messageCreate", async message=>{
  if(message.author.bot) return;
  if(!message.content.startsWith(prefix)) return;
  const [cmd, ...args] = message.content.slice(prefix.length).trim().split(/ +/);

  // help (owners only)
  if(cmd==="help"){
    if(!isOwner(message.author.id)) return message.reply("❌ هذا الأمر للأونر فقط");
    const embed = new EmbedBuilder()
      .setColor(0x1f8bff)
      .setTitle("🛡️ أوامر الأونر")
      .setDescription(`
**إدارة البوت:**
${prefix}setavatar (ارفع صورة أو استخدم رابط)
${prefix}setname الاسم_الجديد
${prefix}setstatus النص

**النقاط:**
${prefix}setpoints + @user 10
${prefix}setpoints - @user 5
${prefix}نقاطي
${prefix}top

**شرح الأدوار:**
${prefix}شرح <الدور>
      `);
    return message.reply({embeds:[embed]});
  }

  // setavatar
  if(cmd==="setavatar"){
    if(!isOwner(message.author.id)) return;
    if(message.attachments.size>0){
      const url = message.attachments.first().url;
      try{ await client.user.setAvatar(url); return message.reply("✅ تم تغيير صورة البوت"); }catch(e){ return message.reply("❌ فشل تغيير الصورة"); }
    }
    const url = args[0];
    if(!url) return message.reply("📌 ارفع صورة أو ضع رابط");
    try{ await client.user.setAvatar(url); return message.reply("✅ تم تغيير صورة البوت"); }catch(e){ return message.reply("❌ فشل تغيير الصورة"); }
  }

  // setname
  if(cmd==="setname"){
    if(!isOwner(message.author.id)) return;
    const name = args.join(" ");
    if(!name) return message.reply("📌 اكتب اسم");
    try{ await client.user.setUsername(name); return message.reply("✅ تم تغيير الاسم"); }catch(e){ return message.reply("❌ فشل تغيير الاسم"); }
  }

  // setstatus (custom playing)
  if(cmd==="setstatus"){
    if(!isOwner(message.author.id)) return;
    const text = args.join(" ");
    if(!text) return message.reply("📌 اكتب الحالة");
    client.user.setActivity(text, { type: 0 }); // Playing
    return message.reply("✅ تم تغيير الحالة");
  }

  // نقاطي
  if(cmd==="نقاطي"){
    getPoints(message.author.id, (score)=> message.reply(`🏆 نقاطك: **${score}**`));
  }

  // setpoints
  if(cmd==="setpoints"){
    if(!isOwner(message.author.id)) return;
    const operator = args[0];
    const target = message.mentions.users.first();
    const amount = parseInt(args[1]);
    if(!target || isNaN(amount) || !["+", "-"].includes(operator)) return message.reply(`📌 مثال:
${prefix}setpoints + @user 10`);
    const final = operator==="+"? amount : -amount;
    addPoints(target.id, final);
    return message.reply(`✅ تم تعديل نقاط <@${target.id}>`);
  }

  // top
  if(cmd==="top"){
    db.all("SELECT * FROM points ORDER BY score DESC LIMIT 10", [], (err, rows)=>{
      if(!rows || rows.length===0) return message.reply("لا يوجد بيانات بعد");
      const list = rows.map((r,i)=>`**${i+1}.** <@${r.id}> — ${r.score}`).join("\n");
      const embed = new EmbedBuilder().setColor(0x1f8bff).setTitle("🏆 المتصدرين").setDescription(list);
      return message.reply({embeds:[embed]});
    });
  }

  // شرح
  if(cmd==="شرح"){
    const role = args.join(" ").toLowerCase();
    if(!role) return message.reply("📌 مثال: .شرح الساحرة");
    const roles = {
      "الساحرة":"لديها جرعة إنقاذ وجرعة قتل تستخدم كل واحدة مرة واحدة فقط.",
      "الذئب":"يتشاور مع الذئاب ويختارون شخص للقتل كل ليلة.",
      "العراف":"يستطيع معرفة دور لاعب كل ليلة.",
      "الحارس":"يحمي لاعب من القتل، لكن لا يحمي نفس الشخص مرتين متتاليتين."
    };
    if(!roles[role]) return message.reply("❌ الدور غير موجود.");
    return message.reply(`**${role}:** ${roles[role]}`);
  }

  // بدء اللعبة -ذيب (مختصر)
  if(cmd==="الذيب"){
    if(!isOwner(message.author.id)) return;
    let timeLeft=30;
    let players=[];
    const startImage = path.join(__dirname, "assets/images", cfg.images.start);
    const joinBtn = new ButtonBuilder().setCustomId("join_game").setLabel("دخول").setStyle(ButtonStyle.Success);
    const leaveBtn = new ButtonBuilder().setCustomId("leave_game").setLabel("انسحاب").setStyle(ButtonStyle.Danger);
    const row = new ActionRowBuilder().addComponents(joinBtn, leaveBtn);

    let msg = await message.channel.send({
      content:`@everyone\n🎮 بدأت اللعبة!\n👥 لاعبون: 0/${cfg.maxPlayers}\n⌛ الوقت: ${timeLeft} ثانية`,
      files:[startImage],
      components:[row]
    });

    const interval = setInterval(()=>{
      timeLeft--;
      msg.edit({
        content:`@everyone\n🎮 بدأت اللعبة!\n👥 لاعبون: ${players.length}/${cfg.maxPlayers}\n⌛ الوقت: ${timeLeft} ثانية`,
        files:[startImage],
        components:[row]
      });
      if(timeLeft<=0){
        clearInterval(interval);
        row.components.forEach(b=>b.setDisabled(true));
        msg.edit({components:[row]});
      }
    },1000);

    client.on("interactionCreate", async inter=>{
      if(!inter.isButton()) return;
      if(inter.customId==="join_game"){
        if(!players.includes(inter.user.id)) players.push(inter.user.id);
        return inter.reply({content:"✅ انضممت", ephemeral:true});
      }
      if(inter.customId==="leave_game"){
        players = players.filter(p=>p!==inter.user.id);
        return inter.reply({content:"❌ غادرت", ephemeral:true});
      }
    });
  }

});

client.on("ready", ()=> console.log("Ready:", client.user.tag));
client.login(cfg.token);
